import { Component, OnInit } from '@angular/core';
import {DynamicDialogRef} from 'primeng/dynamicdialog';
import {DynamicDialogConfig} from 'primeng/dynamicdialog';
import { CommunicationService } from '../services/communication.service';

@Component({
  selector: 'app-note',
  templateUrl: './note.component.html',
  styleUrls: ['./note.component.scss']
})
export class NoteComponent implements OnInit {
  noteData='';
  LocposData: any;
  constructor( public ref: DynamicDialogRef, public config: DynamicDialogConfig, private communicationService: CommunicationService) { }

  ngOnInit(): void {
    this.LocposData = this.config.data.posData;
  }

  save(){
    let newPos = {  latitude: this.LocposData.iss_position.latitude, longitude: this.LocposData.iss_position.longitude, note: this.noteData, timestamp: this.LocposData.timestamp }
    this.communicationService.addPos(newPos);
  }
}
