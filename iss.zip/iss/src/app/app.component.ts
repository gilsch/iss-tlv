import { Component, OnInit } from '@angular/core';
import {map, Subscription, timer} from 'rxjs';  
import { CommunicationService } from './services/communication.service';
import { first } from 'rxjs/operators';
import {DialogService} from 'primeng/dynamicdialog';
import { NoteComponent } from './note/note.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [DialogService]
})

export class AppComponent implements OnInit{

  constructor(private communicationService: CommunicationService, public dialogService: DialogService) { }

  title = 'iss';
  timerSubscription: Subscription; 
  posData: any;
  

  ngOnInit() {
    this.timerSubscription = timer(0, 2000).pipe( 
      map(() => { 
        this.getData(); 
      }) 
    ).subscribe(); 
  }

  getData(){
    this.communicationService.getData()
    .pipe(first())
    .subscribe((PosData) => {
       
      if(PosData && PosData["message"].toLowerCase() === 'success'){
        this.posData = PosData;
      }
      else{alert('Error');}    
     })
  }

  show() {
    const ref = this.dialogService.open(NoteComponent, {
      data: {
        posData: this.posData
      },
      header: 'Write Note',
      width: '60%'     
    });
}


}
