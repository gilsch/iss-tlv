import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PosData } from '../models/issposition';

const baseUrl = 'http://api.open-notify.org/iss-now.json';
//const apiUrl = 'https://localhost:7245/Home/addPos';
const apiUrl = 'https://localhost:7245/Home/';

@Injectable({
  providedIn: 'root'
})
export class CommunicationService {

  constructor(private http: HttpClient) { }

  getData() {
    return this.http.get<PosData[]>(baseUrl);
  } 

  addPos(params: any){    
    debugger
    return this.http.post(apiUrl , {params}); 
  }

}
