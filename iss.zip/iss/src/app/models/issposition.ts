
export class PosData {
    message: string;
    timestamp: string;
    iss_position: IssPosition;
}

export class IssPosition {
    latitude: string;
    longitude: string;
}

