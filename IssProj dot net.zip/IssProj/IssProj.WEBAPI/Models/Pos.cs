﻿namespace IssProj.WEBAPI.Models
{
    public class Pos
    {
        public string timestamp { get; set; }
        public double latitude { get; set; }
        public double longitude { get; set; }
        public string note { get; set; }
    }
}
