﻿using IssProj.WEBAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualBasic;
using System;
using System.IO;
using System.Collections.Generic;

namespace IssProj.WEBAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class HomeController : ControllerBase
    {
         public List<Pos> PosList = new List<Pos>();

        [HttpPost]
        public List<Pos> AddPos(Pos AddPos)
        {
            PosList.Add(AddPos);

            return PosList;
        }



    }
}
